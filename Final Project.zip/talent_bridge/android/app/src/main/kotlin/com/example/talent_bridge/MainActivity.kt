package com.example.talent_bridge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
